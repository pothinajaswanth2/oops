/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //loops in c++
    //for loops syntax - for(initializtion;condition;updation){}
    /*for(int i=1;i<100;i++){
        cout<<i<<endl;
    }*/
    
    //Example for infinite loops
   /* for(int i =1;34<=40;i++){
        cout<<i++<<endl;
    }
    //while loops
    int i=1;
    while(i<=40){
        cout<<i<<endl;
        i++;
    }*/
    
    //Example for infinite while loops
    /*int i=1;
    while(true){
        cout<<i<<endl;
        i++;
    } */
    int i =1;
    do{
        cout<<i<<endl;
        i++;
    }while(i<=40);
    return 0;
}
