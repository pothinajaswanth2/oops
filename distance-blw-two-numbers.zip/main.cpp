/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;

class point{
    float x,y;
    friend void distance(point, point);
    public:
    point(float a, float b){
        x = a;
        y = b;
    }

    void displayPoint()
    {
        cout<<"The point is ("<<x<<","<<y<<")"<<endl;
    }
};
void distance(point p1, point p2)
{
    float x_diff = (p2.x-p1.x);
    float y_diff = (p2.y-p1.y);
    float
    diff = sqrt(pow(x_diff,2)+pow(y_diff,2));
    cout<<"The difference is "<<diff<<endl;
}

int main(){
    point p(1,1);
    p.displayPoint();
    
    point q(2,3);
    q.displayPoint();
    
    distance(p,q);
    return 0;
}