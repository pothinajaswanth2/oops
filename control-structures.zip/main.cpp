/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{   
    // selection control structure: if-else-if ladder 
    int age;
    //cout<<"This is tutorial 9";
    cout<<"Tell me your age"<<endl;
    cin>>age;
    /*
    if((age<18) && (age >0))
    {
        cout<<"You are not eligible to vote "<<endl;
    }
    else if(age == 18)
    {
        cout<<"You are eligible to vote "<<endl;
    }
    else if(age<1){
        cout<<"you are not yet born "<<endl;
    }
    else
    {
        cout<<"You are eligible to drink "<<endl;
    }*/
    // switch case
    switch(age){
        case 18:
        cout<<"You are 18 "<<endl;
        break; // if we dont use break then it will print the all cases
         case 22:
        cout<<"You are 22 "<<endl;
        break;
         case 2:
        cout<<"You are 18 "<<endl;
        break;
        default:
        cout<<"No special cases"<<endl;
        break;
    }
    return 0;
}
