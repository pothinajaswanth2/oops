/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //pointer
    int a=3;
    int* b = &a;
    // & --> address operator
    // * --> dereferencing operator(value at)
    cout<<"The address of a is"<<&a;
    cout<<"\nthe address of a is "<<b;
    cout<<"\nThe value at address b is "<<*b<<endl;
    
    //pointer to pointer
    int** c =&b; //Here c is newly created pointer and b is already a pointer
    cout<<"The address of b is"<<&b<<endl;
    cout<<"The address of b is"<<c<<endl;
    cout<<"The value at address c is"<<**c<<endl;
    cout<<"The values at address value_at(value_at(c)) is"<<*c<<endl;
    return 0;
}
