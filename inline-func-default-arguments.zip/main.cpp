/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

/*int product(int a, int b){
    static int c = 0; // This excutes only once
    c = c+1;
    return a*b+c;
}
/*inline int product(int a, int b){
    return a*b;
}*/
int moneyReceived(int currentMoney, int factor = 1.08){
    return currentMoney*factor;
}

int main()
{
    int a, b;
    /*cout<<"Enter the value of a and b ";
    cin>>a>>b;*/
    int money = 100000;
    cout<<"If you have"<<money<<"Rs in your bank, you will recieve "<<moneyReceived(money)<<"rs after 1 year";
    cout<<"For VIP: If you have"<<money<<"Rs in your bank, you will recieve "<<moneyReceived(money,1.1)<<"rs after 1 year";
    /*cout<<"\nThe product of a and b is "<<product(a,b);
        cout<<"The product of a and b is "<<product(a,b);
    cout<<"\nThe product of a and b is "<<product(a,b);
    cout<<"\nThe product of a and b is "<<product(a,b);
    cout<<"\nThe product of a and b is "<<product(a,b);
    cout<<"\nThe product of a and b is "<<product(a,b);
    cout<<"\nThe product of a and b is "<<product(a,b);
        cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);
    cout<<"The product of a and b is "<<product(a,b);*/


    return 0;
}