/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

class Student
{
    protected:
    int roll_no;
    public:
    void set_number(int a)
    {
        roll_no = a;
    }    
    void print_number(void)
    {
        cout<<"Your roll no is "<<roll_no<<endl;
    }
};

class Test: virtual public Student{
    protected:
    float maths, physics;
    public:
    void set_marks(float m1, float m2)
    {
        maths = m1;
        physics = m2;
    }
    void print_marks(void)
    {
        cout<<"Your result is here: "<<endl
        <<"Maths: "<<maths<<endl
        <<"Physics: "<<physics<<endl;
    }
};
class sports: virtual public Student{
    protected:
    float score;
    public:
    void set_score(float sc)
    {
        score = sc;

    }
    void print_score()
    {
        cout<<"Your final score is "<<score<<endl;
    }
};

class result: public Test, public sports{

    private:
    float total;
    public:
    void display(void)
    {
        total = maths+ physics+score;
        print_number();
        print_marks();
        print_score();
        cout<<"Your total score is: "<<total<<endl;
    }
};

int main(){
    result jaswanth;
    jaswanth.set_number(8842468);
    jaswanth.set_marks(78,92);
    jaswanth.print_marks();
    jaswanth.set_score(98);
    jaswanth.print_score();
    jaswanth.display();
    return 0;
}
