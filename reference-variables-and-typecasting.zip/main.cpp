/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   /*int a,b,c;
   cout<<"Enter the value of a:"<<endl;
   cin>>a;
   cout<<"Enter the value of b:"<<endl;
   cin>>b;
   c = a+b;
   cout<<"The sum is "<<c;
   cout<<"The global c is"<<::c;
   
   float d=34.4f; //f means floating point
   long double e = 34.4l; //l means the long
   cout<<"The size of 34.4 is "<<sizeof(34.4)<<endl;
   cout<<"The size of 34.4f is "<<sizeof(34.4f)<<endl;
   cout<<"The size of 34.4l is "<<sizeof(34.4l)<<endl;
   cout<<"The size of 34.4F is "<<sizeof(34.4F)<<endl;
   cout<<"The size of 34.4L is "<<sizeof(34.4L)<<endl;
   
   cout<<"The value of d is "<<d<<endl<<"The value of e is"<<e;*/
   
   /******************reference variables**********************/
   /*float var = 455;
   float & y =var;
   cout<<var<<endl;
   cout<<y<<endl;
    /***************************Type casting*******************/
    int a = 45;
    int b = 45.46;
    cout<<"The value of a is "<<(float)a; 
    cout<<"\nThe value of a is "<<float(a);
    
    cout<<"\nThe value of b is "<<(int)b;
    cout<<"\nThe value of b is "<<int(b);
    int c = int(b);
    
    cout<<"\nthe expression is : "<<a+b;
    cout<<"\nThe expression is : "<<a + int(b);
    cout<<"\nThe expression is : "<<a+ (int)b;
    return 0;
}
