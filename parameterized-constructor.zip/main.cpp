/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

class complex{
    int a,b;
    public:
    complex(int, int);

    void printNumber(){
        cout<<"Your number is "<<a<<"+"<<b<<"i"<<endl;
    }
};
complex:: complex(int x, int y) //parameterized constructor
{
    a=x;
    b=y;
}

int main(){
    //implicit call
    complex c(5,6);
    c.printNumber();
   // explicit call
    complex c1 = complex(7,8);
    c1.printNumber();
    return 0;
} 