/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class employee{
    int id;
    static int count;
    public:
        void setData(void){
            cin>>id;
            cin>>count;
        }
        void getData(void){
            cout<<"The id of this employee is "<<id<<" This is the employee number "<<count<<endl;
        }
        static void getcount(void){
            cout<<"The value of count is"<<count<<endl;
        }
};
int employee:: count; //by default the value is 0
int main()
{
    employee harry;
    harry.setData();
    harry.getData();
    employee::getcount();
    

    return 0;
}