/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class employee
{
  int id;
  int salary;
public:
  void setId (void)
  {
    salary = 122;
    cout << "enter id of an employee ";
    cin >> id;
  }

  void getId (void)
  {
    cout << "The id of this employee " << id << endl;
  }
};

int main ()
{
  // employee HARRY,ravi,jaswanth;
  // HARRY.setId();
  // HARRY.getId();
  employee fb[4];
  for (int i = 0; i < 4; i++)
    {
      fb[i].setId ();
      fb[i].getId ();
    }

  return 0;
}
