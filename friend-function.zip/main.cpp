/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

//complex numbers are the numbers which are having both real and imaginary values

class complex
{
  int a, b;
public:
  void setNumber (int n1, int n2)
  {
    a = n1;
    b = n2;
  }
  friend complex sum (complex o1, complex o2);

  void printNumber ()
  {
    cout << "Your number is " << a << "+" << b << "i" << endl;
  }
};

complex sum (complex o1, complex o2)
{
  complex o3;
  o3.setNumber ((o1.a + o2.a), (o1.b + o2.b));
  return o3;

}

int  main ()
{
  complex c1, c2, sum1;
  c1.setNumber (1, 4);
  c1.printNumber ();

  c2.setNumber (1, 8);
  c2.printNumber ();

  sum1 = sum (c1, c2);
  sum1.printNumber ();
  return 0;
}
