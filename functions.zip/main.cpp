/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int sum(int,int);
//int sum(int a, int b);// it will tell the compiler there is a function infront
/*int sum(int a, int b){
    int c = a+b;
    return c;
}*/
//void p(void);
int main()
{
    int num1, num2;
    cout<<"Enter first number: ";
    cin>>num1;
    cout<<"\nEnter second number: ";
    cin>>num2;
    //num 1 and num 2 are actual parameters
    cout<<"\nThe sum is "<<sum(num1,num2);
    p();
    return 0;
    
}

int sum(int a, int b){
    // formal parameters a and b will be taking values from actual parameters num1 and num2.
    int c = a+b;
    return c;
}

void p(){
    cout<<"\nHello, good morning";
}