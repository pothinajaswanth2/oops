/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

typedef struct employee
{
    int eid;
    char favChar;
    float salary;
}ep;
union money
{
    int rice;
    char car;
    float pounds;
};

int main()
{
    enum Meal{breakfast, lunch, dinner};
    cout<<breakfast;
    cout<<lunch;
    cout<<dinner;
   /* ep harry;
    union money m1;
    m1.rice = 34;
    m1.car = 'B';
    cout<<m1.rice;
    //struct employee harry;
    /*harry.eid = 1;
    harry.favChar = 'c';
    harry.salary = 1200000;
    cout<<harry.eid<<endl;
    cout<<harry.favChar<<endl;
    cout<<harry.salary<<endl;*/

    return 0;
}
