/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class complex{
    int a,b;
    public:
    complex(void);
    
    void printNumber(){
        cout<<"Your number is "<<a<<"+"<<b<<"i"<<endl;
    }
};

complex :: complex(void) //default constructor 
{
    a = 10;
    b = 0;
}
int main()
{
    complex c,c1,c2;
    c.printNumber();
    c1.printNumber();
    c2.printNumber();
    return 0;
}