/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int glo = 6;

void sum(){
    int a; //local variable >> Global variable
    cout<<glo;
}
int main()
{
    int glo = 9;
    glo = 78;
    //int a = 4;
    //int b = 5;
    int a =4,b=5;
    float c = 3.14;
    char d ='j';
    sum();
    cout<<"This global variable "<<glo<<".";
    cout<<"This is tut 4. Here the value of a is "<<a<<".The value of b is "<<b;
    cout<<"\nThe value of pi is "<<c;
    cout<<"\nThe char is "<<d;
    return 0;
}