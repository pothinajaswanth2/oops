/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<iomanip> //this header is for manipulators
using namespace std;

int main()
{
    /*int a = 34;
    cout<<"The value of a was: "<<a;
    a = 45;
    cout<<"The value of a is: "<<a;
    
   /* const float a =3.11;
    cout<<"The value of a is: "<<a<<endl;
    a =45;
    cout<<"The value of a is: "<<a<<endl;
    return 0;*/
    
    int a=3, b=78, c=1233;
    cout<<"The value of a without sdt is:"<<a<<endl;
    cout<<"The value of b without sdt is:"<<b<<endl;
    cout<<"The value of c without sdt is:"<<c<<endl;
    
    cout<<"The value of a is:"<<setw(4)<<a<<endl;
    cout<<"The value of b is:"<<setw(4)<<b<<endl;
    cout<<"The value of c is:"<<setw(4)<<c<<endl; 
    return 0;
}

