/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

 class binary
 {
        string s;
        public:
            void read(void);
            void chk_bin(void);
            void ones(void);
            void display(void);
            
};
void binary :: read(void)
{
    cout<<"Enter a binary number "<<endl;
    cin>>s;
}

void binary :: chk_bin(void)
{
    for(int i = 0;i< s.length();i++)
    {
        if(s.at(i)!='0' && s.at(i)!='1')
        {
            cout<<"Incorrect binary format "<<endl;
            exit(0);
        }
    }
}

void binary :: ones(void)
{
    chk_bin();
    for(int i =0; i<s.length();i++)
    {
        if(s.at(i) =='0'){
            s.at(i) = '1';
        }
        else
        {
            s.at(i) = '0';
        }
        
    }
}
void binary :: display(void)
{
    int i;
    cout<<"Displaying binary numbers"<<endl;
    for(int i=0; i<s.length(); i++)
    {
    cout<<s.at(i);
    }
    cout<<endl;
}
int main()
{
    //by default it should be the 
    //c++ was implemented by the bjrane strostroup
    //classes are the blueprints or structure of an Objective
    //objects are instance of class
   
    binary b;
    b.read();
    //b.chk_bin();
    b.display();
    b.ones();
    b.display();

    return 0;
}

