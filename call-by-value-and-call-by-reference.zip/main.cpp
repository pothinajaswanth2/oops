/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int sum(int a, int b){
    int c = a+b;
    return c;
    
}
// This will not swap a and b
/*void swap (int a , int b){
    int temp = a;
    a =b;
    b = temp;
}*/
//This will work in this it will share the address
//call by reference using pointers
/*void swap(int *a, int *b){
    int temp= *a;
    *a=*b;
    *b = temp;
}*/
//call by reference using reference variables
void swapreference(int &a , int &b){
    int temp= a;
    a=b;
    b = temp;
}
int main()
{
    int x = 4, y = 5;
    //cout<<"The sum of 4 and 5 is "<<sum(a,b);
    cout<<"The value of  x before swapping is "<<x<<"\nThe value of y before swapping is "<<y;
    //swap(&x,&y);
    swapreference(x,y);
    cout<<"\nThe value of x aftern swapping is "<<x<<"\nThe value y after swapping is "<<y;
    return 0;
}