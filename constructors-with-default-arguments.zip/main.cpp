/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class simple{
    int data1;
    int data2;
    int data3;
    public:
    simple(int a, int b, int c=8) //these are dafault arguments
    {
        data1 = a;
        data2 = b;
        data3 = c;
    }
    void printData();
};
void simple:: printData(){
    cout<<"The values of the Data is "<<data1<<","<<data2<<"and"<<data3<<endl;
}
int main()
{
    simple s(1,2);
    s.printData();

    return 0;
}