/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class bankdeposit
{
    int principal;
    int years;
    float intrestrate;
    float returnValue;
    public:
    bankdeposit(){}
    bankdeposit(int p, int y, float r);
    bankdeposit(int p, int y, int R);
    
    void show(void);
};

bankdeposit:: bankdeposit(int p, int y, float r)
{
    principal =p;
    years = y;
    intrestrate = r;
    returnValue = principal;
    for(int i=0; i<y; i++)
    {
        returnValue = returnValue * (1+r);
    }
}

bankdeposit:: bankdeposit(int p, int y, int R)
{
    principal =p;
    years = y;
    intrestrate = float(R)/100;
    returnValue = principal;
    for(int i=0; i<y; i++)
    {
        returnValue = returnValue * (1+intrestrate);
    }
}

void bankdeposit :: show(){
    cout<<"principal amount was "<<principal<<"return Value after "<<years<<" year"<<".Return value is "<<returnValue<<endl;
}
int main()
{
    bankdeposit bd1, bd2, bd3;
    int p,y;
    float r;
    int R;
    
    cout<<"Enter the value of p y and r"<<endl;
    cin>>p>>y>>r;
    bd1 = bankdeposit(p,y,r);
    bd1.show();
    
    cout<<"Enter the value of p y and R"<<endl;
    cin>>p>>y>>R;
    bd1 = bankdeposit(p,y,R);
    bd1.show();
    return 0;
}
