/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
//syntax for intializtion list in constructor:

class test
{
    // int a;
    int b;
    int a;
public:
// test(int i, int j): a(i), b(j)
    test(int i, int j): b(j), a(i+b)
    {
        cout<<"constructor excuted"<<endl;
        cout<<"The value of a is "<<a<<endl;
        cout<<"The value of b is "<<b<<endl;
    }
};
int main(){
    test t(4,6);
    return 0;
}
