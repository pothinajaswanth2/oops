/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a,b;
    cout<<"Enter the value of a :";
    cin>>a;
    cout<<"Enter the value of b :";
    cin>>b;
    cout<<"operators in c++"<<endl;
    cout<<"Following are the types of operator in c++"<<endl;
    
    //Arithematic operator
    cout<<"The value of a+b is "<<a+b;
    cout<<"\nThe value of a-b is "<<a-b;
    cout<<"\nThe value of a/b is "<<a/b;
    cout<<"\nThe value of a*b is "<<a*b;
    cout<<"\nThe value of a%b is "<<a%b;
    //incremental operators
    cout<<"\nThe value of a++ is "<<a++; //4 --> 5
    cout<<"\nThe value of a-- is "<<a--; //5 --> 4
    cout<<"\nThe value of ++a is "<<++a; //4+1 --> 5
    cout<<"\nThe value of --a is "<<--a; // 5-1 --> 4
    
    //logical operators
    cout<<"\nFollowing are the logical operators in c++"<<endl;
    cout<<"The value of this logical and operator ((a==b) && (a<b)) is: "<<((a==b) && (a<b))
    <<endl;
    cout<<"The value of this logical or operator ((a==b) || (a<b)) is: "<<((a==b) || (a<b))
    <<endl;
    cout<<"The value of this logical not operator (!(a==b)) is: "<<(!(a==b))<<endl;
    return 0;
    
}
