/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class complex{
    int a,b;
    public:
    complex(){
        a = 0;
        b = 0;
    }
    complex(int x, int y)
    {
        a = x;
        b = y;
    }
    complex(int x)
    {
        a =x;
        b =0;
    }
    void printNumber()
    {
        cout<<"Your number is "<<a<<"+"<<b<<"i"<<endl;
    }
};

int main()
{
    complex c(5,6);
    c.printNumber();
    
    complex c1(2);
    c1.printNumber();
    
    complex c3;
    c3.printNumber();
    return 0;
}